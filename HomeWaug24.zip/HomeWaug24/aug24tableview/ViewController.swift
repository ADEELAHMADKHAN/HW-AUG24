//
//  ViewController.swift
//  aug24tableview
//
//  Created by Cosultant on 8/24/22.
//

import UIKit

class ViewController: UIViewController {
    
    //MARK: - IBOutlet
    @IBOutlet weak var messageUILabel: UILabel!
    //MARK: - VIEW LIFECYCLE
    override func viewDidLoad(){
        super.viewDidLoad()
    }
    
    @IBAction func menuButton(_ sender: Any){
        let vc = storyboard?.instantiateViewController(withIdentifier: "ListViewController") as! ListViewController
        
        //vc.menuList = ["DRINKS","POTATOES","SALAD","FISH","BAKED CHICKEN","FRIED SHRIMP"]
        vc.delegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
//MARK: - DataEnteredDelegate
extension ViewController: DataEnteredDelegate{
    func userDidEnterInformation(info: String) {
            self.messageUILabel?.text = info.capitalized
        }
}
//MARK: - DataEnteredDelegate1
extension ViewController: DataEnteredDelegate1{
    func userDidEnterInformation1(info: String) {
            self.messageUILabel?.text = info.capitalized
        }
}
