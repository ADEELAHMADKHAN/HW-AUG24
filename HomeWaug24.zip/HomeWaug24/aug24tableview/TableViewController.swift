//
//  TableViewController.swift
//  aug24tableview
//
//  Created by Cosultant on 8/24/22.
//

import UIKit

protocol DataEnteredDelegate{
    func userDidEnterInformation(info: String)
}

class TableViewController: UITableViewController{
    
    var delegate: DataEnteredDelegate?
    var menuList:[String] = []
    let cell = "cell"
    
    override func viewDidLoad(){
        super.viewDidLoad()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: cell)
        tableView.delegate = self
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return menuList.count
    }


    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        // Configure the cell...
        cell.textLabel?.text = menuList[indexPath.row].capitalized
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
        {
            let message = menuList[indexPath.row]
            if self.delegate != nil {
                self.delegate?.userDidEnterInformation(info: message)
                self.navigationController?.popToRootViewController(animated: true)
        }
    }
}


