//
//  ListViewController.swift
//  aug24tableview
//
//  Created by Cosultant on 8/25/22.
//


import UIKit

protocol DataEnteredDelegate1{
    func userDidEnterInformation1(info: String)
}


class ListViewController: UIViewController {
var menuList = [MenuList]()
var delegate:DataEnteredDelegate1?
    override func viewDidLoad() {
        super.viewDidLoad()
        menuList = [MenuList(image: "adeel", name: "drinks"), MenuList(image: "image1", name: "FOOD"), MenuList(image: "image1", name: "DESSERT")]
        //["DRINKS","POTATOES","SALAD","FISH","BAKED CHICKEN","FRIED SHRIMP"]
        self.navigationItem.title = "list of food"
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension ListViewController: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        menuList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"ListTableViewCell" , for: indexPath) as! ListTableViewCell
        let data = menuList[indexPath.row]
        cell.nameLabel?.text = data.name
        cell.userImageView?.image = UIImage(named: data.image)
        //cell.nameLabel?.text = menuList[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = menuList[indexPath.row]
        delegate?.userDidEnterInformation1(info: data.name )
        //delegate?.userDidEnterInformation1(info: menuList[indexPath.row])
        navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
}

struct MenuList{
    var image: String
    var name: String
}
